<?php $__env->startSection('detailsuara', 'active'); ?>
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="card">
        <div class="card-header">
            <center>Detail Suara Masuk</center>
        </div>
        <div class="card-body">
            <table class="table table-stripped" id="datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemilih</th>
                        <th>Nama Kandidat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $suara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($suara->firstItem() + $key); ?></td>
                        <td><?php echo e($item->nama_pemilih); ?></td>
                        <td><?php echo e($item->nama_kandidat); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($suara->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\pemiluKMHD\pemilu\resources\views/Page/detailsuara.blade.php ENDPATH**/ ?>