<?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->startSection('konten'); ?>
<?php if(Session::has('status-vote-gagal')): ?>
    <script>
    errorAlert("Vote Gagal")
    </script>
<?php endif; ?>
<div class="row">
    <?php $__currentLoopData = $kandidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
        <div class="card">
            <div class="card-header">
                <center>
                    <h1></h1>
                </center>
            </div>
            <div class="card-body">
                <center><a href="#" data-toggle="modal" data-target="#vote<?php echo e($item->nim); ?>"><img
                            src="<?php echo e($item->photo); ?>"></a></center>
            </div>
            <div class="card-footer">
                <center>
                    <h3><?php echo e($item->nama_lengkap); ?></h3>
                </center>
                <button type="button" class="btn btn-default btn-lg col-md-12" data-toggle="modal"
                    data-target="#visimisi<?php echo e($item->nim); ?>">Visi & Misi</button>
            </div>
        </div>
    </div>

    <!-- Modal Vote -->
    <div class="modal fade" id="vote<?php echo e($item->nim); ?>" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <br>
                    <!-- <h4 class="modal-title">Vote Kandidat</h4> -->
                </div>
                <form method="POST" action="/vote">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <input type="text" name="nim" value="<?php echo e($item->nim); ?>" hidden="true">
                        <h3 style="color: black;">Yakin ingin memilih <strong>
                            </strong> ?</h3>
                        <h3 style="color: black;"><strong>Administrator </strong>tidak dapat melakukan
                            voting</h3>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" name="btnVote">Vote</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Visi Misi -->
    <div class="modal fade" id="visimisi<?php echo e($item->nim); ?>" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <br>
                    <!-- <h4 class="modal-title">Vote Kandidat</h4> -->
                </div>
                <div class="modal-body">
                    <strong class="h2" style="color: black;">Visi</strong>
                    <p><?php echo e($item->visi); ?></p><br>
                    <strong class="h2" style="color: black;">Misi</strong>
                    <p><?php echo e($item->misi); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\pemiluKMHD\pemilu\resources\views/Page/index.blade.php ENDPATH**/ ?>