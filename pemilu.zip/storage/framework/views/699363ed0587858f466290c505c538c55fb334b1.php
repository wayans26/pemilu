<?php $__env->startSection('status', 'active'); ?>
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">NIM</th>
                        <th scope="col">Ip Address</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody class="statusUser">

                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    getStatus();
    setInterval(getStatus, 1000);
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function getStatus() {
        $.ajax({
            type: 'POST',
            url: '/status',
            data: {
                "_token": "<?php echo e(csrf_token()); ?>"
            },
            success: function (data) {
                // console.log(data);
                setStatus($.parseJSON(data))

            },
            error: function (data) {
                console.log(data);

                getStatus();
            }
        });
    }

    function setStatus(data) {
        console.log(data);

        if (data.status === 1) {
            tmpData = "";
            for (i = 0; i < data.data.length; i++) {
                tmpData += "<tr><th>" + data.data[i].nim + "</th><td>" + data.data[i].ip_address +
                    "</td><td>" + data.data[i].status + "</td></tr>";
            }
            $(".statusUser").html(tmpData);
        } else {
            // alert("Terjadi Kesalahan Pada Database..!!");
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\pemiluKMHD\pemilu\resources\views/Page/status.blade.php ENDPATH**/ ?>