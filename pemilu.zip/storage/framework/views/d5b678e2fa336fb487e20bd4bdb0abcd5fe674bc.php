<?php $__env->startSection('pemilih', 'active'); ?>
<?php $__env->startSection('konten'); ?>

<?php if(Session::has('status-tambah-berhasil')): ?>
<script>
    successAlert("<?php echo Session::get('status-tambah-berhasil'); ?>");

</script>
<?php elseif(Session::has('status-tambah-gagal')): ?>
<script>
    errorAlert("<?php echo Session::get('status-tambah-gagal'); ?>");

</script>
<?php elseif(Session::has('status-update-berhasil')): ?>
<script>
    successAlert("<?php echo Session::get('status-update-berhasil'); ?>");

</script>
<?php elseif(Session::has('status-update-gagal')): ?>
<script>
    errorAlert("<?php echo Session::get('status-update-gagal'); ?>");

</script>
<?php elseif(Session::has('status-hapus-berhasil')): ?>
<script>
    successAlert("<?php echo Session::get('status-hapus-berhasil'); ?>");

</script>
<?php elseif(Session::has('status-hapus-gagal')): ?>
<script>
    errorAlert("<?php echo Session::get('status-hapus-gagal'); ?>");

</script>
<?php elseif(Session::has('status-active-berhasil')): ?>
<script>
    successAlert("<?php echo Session::get('status-active-berhasil'); ?>");

</script>
<?php elseif(Session::has('status-active-gagal')): ?>
<script>
    errorAlert("<?php echo Session::get('status-active-gagal'); ?>");

</script>
<?php endif; ?>

<div class="row">
    <div class="card">
        <div class="card-header">
            <center>Daftar Pemilih Tetap</center>
        </div>
        <div class="card-body">
            <table class="table table-stripped" id="datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Nim</th>
                        <th>Status Memilih</th>
                        <th>Status Registrasi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pemilih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pemilih->firstItem() + $key); ?></td>
                        <td><?php echo e($item->nama_lengkap); ?></td>
                        <td><?php echo e($item->nim); ?></td>
                        <td><?php echo e($item->status_memilih); ?></td>
                        <td><?php echo e($item->status_register); ?></td>
                        <td>
                            <a href="#" data-toggle="modal" data-target="#edit<?php echo e($item->nim); ?>"><i
                                    class="fa fa-edit"></i></a>
                            <a href="#" data-toggle="modal" data-target="#delete<?php echo e($item->nim); ?>"><i
                                    class="fa fa-trash"></i></a>
                            <?php if($item->status_register === 0): ?>
                            <a href="#" data-toggle="modal" data-target="#active<?php echo e($item->nim); ?>"><i
                                    class="fa fa-check"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <!-- modal update -->
                    <div class="modal fade" id="edit<?php echo e($item->nim); ?>" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Update Data pemilih</h4>
                                </div>
                                <form method="POST" action="/pemilih/update">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="control-label" style="color: black;">Nim</label>
                                            <input type="text" name="nim" value="<?php echo e($item->nim); ?>" class="form-control"
                                                style="color: white;" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label" style="color: black;">Nama</label>
                                            <input type="text" name="nama" value="<?php echo e($item->nama_lengkap); ?>"
                                                class="form-control" style="color: black;">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success" name="btnUpdate">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- modal delete -->
                    <div class="modal fade" id="delete<?php echo e($item->nim); ?>" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <form method="POST" action="/pemilih/hapus">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="modal-body">
                                        <input type="text" hidden="true" name="nim" value="<?php echo e($item->nim); ?>">
                                        <h3 style="color: black;">Yakin ingin menghapus data pemilih <center>
                                                <strong><?php echo e($item->nama_lengkap); ?></strong></center>
                                        </h3>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger" name="btnDelete">Delete</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- modal active -->
                    <div class="modal fade" id="active<?php echo e($item->nim); ?>" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <form method="POST" action="/pemilih/active">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="modal-body">
                                        <input type="text" hidden="true" name="nim" value="<?php echo e($item->nim); ?>">
                                        <h3 style="color: black;">Registrasi? <center>
                                                <strong><?php echo e($item->nama_lengkap); ?></strong></center>
                                        </h3>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success">Registrasi</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <br>
            <?php echo e($pemilih->links()); ?>

            <a href="" class="btn btn-success float-right" data-toggle="modal" data-target='#tambah'>Tambah <i
                    class="fa fa-plus"></i></a>
        </div>
    </div>
</div>

<!-- modal update -->
<div class="modal fade" id="tambah" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Tambah Data pemilih</h4>
            </div>
            <form method="POST" action="/pemilih/tambah">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <label class="control-label" style="color: black;">Nama</label>
                        <input type="text" name="nama" class="form-control" style="color: black;">
                    </div>
                    <div class="form-group">
                        <label class="control-label" style="color: black;">Nim</label>
                        <input type="text" name="nim" class="form-control" style="color: black;">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\pemiluKMHD\pemilu\resources\views/Page/pemilih.blade.php ENDPATH**/ ?>